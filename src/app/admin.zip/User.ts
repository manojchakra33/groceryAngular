import Login from "./Login";

export default class User{
    constructor(public login:Login,public name:string,public mobileNumber:number,public address:any
       ){
            
        }
}